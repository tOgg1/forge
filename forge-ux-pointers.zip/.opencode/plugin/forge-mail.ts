/**
 * Forge Mail + Locks plugin for OpenCode
 *
 * Drop this file into:
 *   - .opencode/plugin/forge-mail.ts   (project-local)
 *   - or ~/.config/opencode/plugin/forge-mail.ts (global)
 *
 * OpenCode plugin docs: https://opencode.ai/docs/plugins/
 *
 * This plugin exposes Forge's mailbox + advisory file locking to agents as tools:
 *   - forge_mail_*
 *   - forge_lock_*
 *
 * Expected dependency: a `forge` binary available in PATH that supports `--json` output.
 */
import { type Plugin, tool } from "@opencode-ai/plugin";

type BunShell = (strings: TemplateStringsArray, ...values: any[]) => {
  text(): Promise<string>;
};

async function runForge($: BunShell, args: any[]): Promise<string> {
  // Bun's `$` template escapes interpolated values, including arrays (as multiple args).
  // See https://bun.sh/docs/runtime/shell
  try {
    const out = await $`forge ${args}`.text();
    return out.trim();
  } catch (err: any) {
    const msg = err?.message ?? String(err);
    throw new Error(`forge ${args.join(" ")} failed: ${msg}`);
  }
}

export const ForgeMailPlugin: Plugin = async ({ $ }) => {
  const exec = (args: any[]) => runForge($ as unknown as BunShell, args);

  return {
    tool: {
      forge_mail_send: tool({
        description:
          "Send a Forge Mail message to one or more agents. Returns JSON when available.",
        args: {
          to: tool.schema.array(tool.schema.string()),
          subject: tool.schema.string().optional(),
          body: tool.schema.string(),
          thread_id: tool.schema.string().optional(),
          importance: tool.schema.string().optional(),
        },
        async execute(args) {
          const cmd: any[] = ["mail", "send", "--json"];
          for (const to of args.to) cmd.push("--to", to);
          if (args.subject) cmd.push("--subject", args.subject);
          if (args.thread_id) cmd.push("--thread", args.thread_id);
          if (args.importance) cmd.push("--importance", args.importance);
          cmd.push("--body", args.body);
          return await exec(cmd);
        },
      }),

      forge_mail_inbox: tool({
        description:
          "List messages in an agent inbox (optionally unread-only). Returns JSON when available.",
        args: {
          agent: tool.schema.string().optional(),
          limit: tool.schema.number().optional(),
          unread_only: tool.schema.boolean().optional(),
        },
        async execute(args) {
          const cmd: any[] = ["mail", "inbox", "--json"];
          if (args.agent) cmd.push("--agent", args.agent);
          if (typeof args.limit === "number") cmd.push("--limit", String(args.limit));
          if (args.unread_only) cmd.push("--unread-only");
          return await exec(cmd);
        },
      }),

      forge_mail_read: tool({
        description: "Read a single Forge Mail message by ID. Returns JSON when available.",
        args: {
          id: tool.schema.string(),
        },
        async execute(args) {
          return await exec(["mail", "read", "--json", args.id]);
        },
      }),

      forge_mail_ack: tool({
        description:
          "Acknowledge (mark read) a Forge Mail message. Returns JSON when available.",
        args: {
          id: tool.schema.string(),
        },
        async execute(args) {
          return await exec(["mail", "ack", "--json", args.id]);
        },
      }),

      forge_lock_claim: tool({
        description:
          "Claim an advisory lock (lease) on one or more paths. Use before editing. Returns JSON when available.",
        args: {
          agent: tool.schema.string(),
          paths: tool.schema.array(tool.schema.string()),
          mode: tool.schema.string().optional(), // 'exclusive' | 'shared'
          ttl_seconds: tool.schema.number().optional(),
          reason: tool.schema.string().optional(),
        },
        async execute(args) {
          const cmd: any[] = ["lock", "claim", "--json", "--agent", args.agent];
          const mode = (args.mode ?? "exclusive").toLowerCase();
          if (mode === "shared") cmd.push("--shared");
          else cmd.push("--exclusive");

          if (typeof args.ttl_seconds === "number") {
            cmd.push("--ttl", `${Math.max(1, Math.floor(args.ttl_seconds))}s`);
          }
          if (args.reason) cmd.push("--reason", args.reason);
          cmd.push(...args.paths);
          return await exec(cmd);
        },
      }),

      forge_lock_release: tool({
        description:
          "Release an advisory lock (lease) on one or more paths. Returns JSON when available.",
        args: {
          agent: tool.schema.string(),
          paths: tool.schema.array(tool.schema.string()),
        },
        async execute(args) {
          const cmd: any[] = ["lock", "release", "--json", "--agent", args.agent, ...args.paths];
          return await exec(cmd);
        },
      }),

      forge_lock_status: tool({
        description:
          "Show current advisory locks (optionally filtered by path). Returns JSON when available.",
        args: {
          path: tool.schema.string().optional(),
        },
        async execute(args) {
          const cmd: any[] = ["lock", "status", "--json"];
          if (args.path) cmd.push(args.path);
          return await exec(cmd);
        },
      }),
    },
  };
};
