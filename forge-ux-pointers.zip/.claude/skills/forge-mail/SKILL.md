---
name: forge-mail
description: Agent-to-agent messaging and advisory file locking via Forge Mail. Use this when coordinating multiple OpenCode sessions/agents on the same repo or across nodes to avoid conflicts, hand off context, or request help.
compatibility: opencode, claude-code
license: MIT
metadata:
  category: coordination
  toolchain: forge
  scope: multi-agent
---

# Forge Mail

Forge Mail is a lightweight **agent-to-agent mailbox** plus **advisory file reservations** (locks).  
Use it to coordinate work across multiple agents, reduce stepping on each other, and create durable handoffs.

## When to use this Skill

Use Forge Mail when you need to:

- Ask another agent to take a task, review a PR, or investigate a bug
- Hand off work (with context) before you go idle or context-compacts
- Coordinate parallel agents so they don't edit the same files
- Reserve files or directories while you work (advisory locks / leases)
- Leave notes for a future session (“resume from here”)

## What tools might be available

Depending on how Forge is installed, you may have one or both of these:

### A) OpenCode custom tools (preferred)

If the OpenCode plugin is installed, you can call tools like:

- `forge_mail_send`
- `forge_mail_inbox`
- `forge_mail_read`
- `forge_mail_ack`
- `forge_lock_claim`
- `forge_lock_release`
- `forge_lock_status`

These tools should return machine-readable JSON or a concise summary.

### B) Forge CLI (fallback)

If custom tools are not available, run the Forge CLI:

- `forge mail send ...`
- `forge mail inbox ...`
- `forge lock claim ...`
- `forge lock release ...`

Tip: add `--json` when you need structured output.

---

## Messaging conventions

### Good subjects

Use short, searchable subjects:

- `[handoff] auth refactor status`
- `[lock-conflict] src/api/auth.ts`
- `[review] PR#123 - payment retries`
- `[question] where is X configured?`

### Message body checklist

Always include enough context so the receiver can act **without** asking follow-ups:

- **Workspace**: name/id (and node if relevant)
- **Repo path** (or repo URL)
- **What you changed / saw**
- **Exact next action** you want
- Links, logs, or file paths
- If you have locks: which locks you hold and TTL/expiry

### Handoff format (recommended)

Use this template:

- **Context**: what we’re doing and why  
- **Current state**: what’s done, what’s not  
- **Files touched**: list paths  
- **Commands run / results**: tests, builds, logs  
- **Next steps**: ordered checklist  
- **Risks / blockers**: anything scary  

---

## Advisory file locking conventions

Forge locks are *advisory*: they don’t prevent edits, but they let well-behaved agents avoid collisions.

### Rules

1. **Claim before edit**: if you’re going to edit a file, claim it first.
2. **Lock the smallest safe scope**: start with file-level locks; lock a folder only if needed.
3. **Use TTL**: locks should expire automatically if you crash or go away.
4. **Release early**: once you’re done with a file, release it.
5. **If you hit a conflict**: do not “race”; message the lock holder.

### Conflict behavior

If a lock cannot be granted:

- Check who holds it and when it expires
- Send them a message asking for a release or a handoff
- If it’s urgent, ask the human operator to decide (do not force)

---

## Examples

### Send a message (tool)

```text
forge_mail_send({
  "to": ["agent:backend-1"],
  "subject": "[review] auth refresh token edge case",
  "body": "Can you review the change in src/auth/refresh.go? Focus: concurrency + expiry edge cases. I ran `go test ./...` and it passed."
})
```

### Read inbox (tool)

```text
forge_mail_inbox({ "agent": "agent:backend-1", "limit": 10, "unread_only": true })
```

### Claim a lock (tool)

```text
forge_lock_claim({
  "agent": "agent:backend-1",
  "paths": ["src/auth/refresh.go"],
  "mode": "exclusive",
  "ttl_seconds": 1800,
  "reason": "Implementing refresh-token fix"
})
```

### Release a lock (tool)

```text
forge_lock_release({ "agent": "agent:backend-1", "paths": ["src/auth/refresh.go"] })
```

### Send a message (CLI)

```bash
forge mail send --to agent:backend-1 --subject "[review] auth refresh token edge case" --body "Please review src/auth/refresh.go ..."
```

### Claim a lock (CLI)

```bash
forge lock claim --agent agent:backend-1 --exclusive src/auth/refresh.go --ttl 30m --reason "Implementing refresh-token fix"
```

---

## Safety and etiquette

- Keep messages actionable and short.
- Avoid spamming; batch updates when possible.
- Prefer “handoff” messages over long back-and-forth.
- Never include secrets in mail bodies.
